# DEHORS — PWA React pour iPhone

## Important
Cette archive fournit le frontend React/Vite installable comme PWA, inspiré de l'interface fournie. Le parcours de session appelle `POST /api/start-session`, mais ce dépôt ne contient pas le backend qui doit implémenter cet endpoint. Sans backend, la préparation de séance affichera un message d'erreur au lieu de prétendre qu'une vidéo a été générée. N'exposez jamais une clé Anthropic dans le navigateur.

## Développement
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
Déployer le contenu de `dist/` sur un hébergement HTTPS. Le service worker et le manifeste permettent l'installation PWA après déploiement.

## Installation sur iPhone
1. Déployer `dist/` sur une adresse HTTPS.
2. Ouvrir cette adresse dans Safari sur l'iPhone.
3. Appuyer sur Partager, puis « Sur l'écran d'accueil » et « Ajouter ».
4. Ouvrir DEHORS depuis l'icône.

## Backend attendu
`POST /api/start-session` reçoit `{ "question": string, "durationMin": 1|3|5 }` et doit répondre en JSON avec au minimum `{ "script": string }`, et éventuellement `videoUrl`. Le serveur doit faire la génération et protéger les secrets. Le frontend ne génère pas encore de vidéo par lui-même.
