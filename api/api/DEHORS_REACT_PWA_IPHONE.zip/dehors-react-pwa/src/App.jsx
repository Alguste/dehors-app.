import React, {useState} from 'react';
import HomeScreen from './screens/HomeScreen.jsx';
import LoadingScreen from './screens/LoadingScreen.jsx';
import PlayerScreen from './screens/PlayerScreen.jsx';
import MainLayout from './components/MainLayout.jsx';
export default function App(){
 const [view,setView]=useState('home'); const [sessionData,setSessionData]=useState({question:'',duration:3,videoUrl:'',script:''});
 const handleStart=(question,duration)=>{setSessionData({question,duration,videoUrl:'',script:''});setView('loading')};
 const handleLoadingComplete=(videoUrl,script)=>{setSessionData(s=>({...s,videoUrl,script}));setView('player')};
 return <div className="min-h-screen bg-dehors-bg text-white font-sans antialiased safe-top safe-bottom">{view==='home'&&<HomeScreen onStart={handleStart} onOpenSpace={()=>setView('space')}/ >}{view==='loading'&&<LoadingScreen question={sessionData.question} durationMin={sessionData.duration} onComplete={handleLoadingComplete} onError={()=>setView('home')}/ >}{view==='player'&&<PlayerScreen question={sessionData.question} durationMin={sessionData.duration} scriptText={sessionData.script} videoUrl={sessionData.videoUrl} onClose={()=>setView('home')}/ >}{view==='space'&&<MainLayout onBack={()=>setView('home')}/>}</div>
}
