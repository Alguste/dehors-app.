/** @type {import('tailwindcss').Config} */
export default { content: ['./index.html','./src/**/*.{js,ts,jsx,tsx}'], theme: { extend: { colors: { dehors: { bg:'#0B111A', card:'#111924', accent:'#FF9B85', accentDark:'#FF7E67' } }, fontFamily: { sans:['Inter','-apple-system','BlinkMacSystemFont','sans-serif'] } } }, plugins: [] };
